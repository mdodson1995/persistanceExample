﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace Persistance
{
    class Program
    {
        static void Main(string[] args)
        {
            Welcome();
            Persist();
        }
        static private void Welcome()
        {
            Console.WriteLine("Hello. Press a key to continue.");
            Console.ReadKey();
        }
        static  void Persist()
        {
            try
            {

                StringBuilder csv = new StringBuilder();
                csv.AppendLine("Name, Age");
                csv.AppendLine("Mathew, 21");
                string path = "C:\\Users\\Mathew\\Desktop\\CIT255\\Random\\Persistance\\Persistance\\data\\content.csv";
                File.AppendAllText(path, csv.ToString());
                Console.WriteLine("Press a key to continue.");
                Console.ReadKey();
            }
            catch (Exception)
            {
                Console.WriteLine("This doesn't work.");
                Console.WriteLine();
                Console.ReadKey();
            }
            finally
            {
                Console.WriteLine("Now it works. Check folders.");
                Console.WriteLine();
                Console.ReadKey();
            }
            }

    }
}
